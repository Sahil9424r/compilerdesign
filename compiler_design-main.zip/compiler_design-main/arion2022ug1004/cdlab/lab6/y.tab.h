#ifndef _yy_defines_h_
#define _yy_defines_h_

#define CHAR 257
#define INT 258
#define FLOAT 259
#define ID 260
#define NUM 261

#endif /* _yy_defines_h_ */
